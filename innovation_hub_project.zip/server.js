const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb+srv://<your-username>:<your-password>@<cluster>.mongodb.net/innovationhub?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const IdeaSchema = new mongoose.Schema({
  title: String,
  content: String,
  createdAt: { type: Date, default: Date.now }
});

const Idea = mongoose.model('Idea', IdeaSchema);

app.get('/', (req, res) => {
  res.send('Innovation Hub API is running');
});

app.post('/ideas', async (req, res) => {
  try {
    const idea = new Idea(req.body);
    await idea.save();
    res.status(201).json({ message: 'Idea saved!', idea });
  } catch (err) {
    res.status(500).json({ message: 'Error saving idea', error: err.message });
  }
});

app.get('/ideas', async (req, res) => {
  try {
    const ideas = await Idea.find().sort({ createdAt: -1 });
    res.json(ideas);
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving ideas', error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));